# VIERA - Alkan Yapı & Viera Web Sitesi

Modern ve dinamik içerik yönetim sistemine sahip inşaat firması web sitesi.

## Özellikler

✅ GitHub tabanlı içerik yönetimi  
✅ Admin paneli ile kolay düzenleme  
✅ Responsive tasarım  
✅ SEO optimize  
✅ Dark/Light mode  
✅ WhatsApp entegrasyonu  
✅ Proje yönetimi (Tamamlanan/Devam Eden)  
✅ Dinamik hizmetler sayfası  

## Kurulum

### 1. GitHub Repository Setup
`GITHUB-SETUP.md` dosyasındaki adımları takip edin.

### 2. Gerekli Environment Variables

\`\`\`bash
GITHUB_TOKEN=your_github_token
GITHUB_OWNER=your_github_username
GITHUB_REPO=your_repository_name
GITHUB_BRANCH=main
\`\`\`

### 3. Deploy to Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

## Admin Panel

Admin paneline erişim: `/admin/login`  
Varsayılan şifre: `admin123`

**İlk girişten sonra şifrenizi değiştirin!**

## Yönetilebilir İçerikler

### Anasayfa
- Video ve başlıklar
- 60 yıllık tecrübe banner'ı
- Hakkımızda bölümü
- İstatistikler

### Projeler
- Tamamlanan projeler
- Devam eden projeler
- Proje detayları ve görseller

### Hizmetler
- Konut projeleri
- Ticari projeler
- Karma kullanım projeleri

### İletişim Bilgileri
- Adres, telefon, e-posta
- Header ve footer otomatik güncellenir

## Teknolojiler

- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- shadcn/ui
- GitHub API
- Vercel

## Lisans

© 2025 VIERA - Alkan Yapı & Viera Ortaklığı  
Tasarım ve Yazılım: [rettocreative.net](https://rettocreative.net)
