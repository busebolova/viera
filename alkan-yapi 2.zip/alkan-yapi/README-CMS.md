# GitHub İçerik Yönetim Sistemi

Bu proje, GitHub'da saklanan JSON dosyalarını yönetmek için Next.js 14 App Router ile oluşturulmuş bir CMS sistemidir.

## Kurulum

### 1. Gereksinimler
- Node.js 18+
- GitHub hesabı
- GitHub Personal Access Token

### 2. GitHub Token Oluşturma
1. GitHub'da Settings > Developer settings > Personal access tokens > Tokens (classic)
2. "Generate new token (classic)" tıklayın
3. Token'a bir isim verin
4. `repo` izinlerini seçin (tüm repo izinleri)
5. Token'ı oluşturun ve kopyalayın

### 3. Ortam Değişkenleri
`.env.local` dosyası oluşturun:

\`\`\`bash
GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
GITHUB_OWNER=kullanici-adiniz
GITHUB_REPO=repo-adiniz
GITHUB_BRANCH=main

ADMIN_EMAIL=admin@vieraconstruction.com
ADMIN_PASSWORD=guclu-sifreniz
\`\`\`

### 4. Content Klasörü
GitHub reponuzda `content/` klasörü oluşturun ve JSON dosyalarını ekleyin:
- content/home.json
- content/about.json
- content/contact.json

## Özellikler

✅ GitHub API ile entegrasyon
✅ Server-side API routes
✅ Gerçek zamanlı commit sistemi
✅ Basit kimlik doğrulama
✅ localStorage kullanılmıyor
✅ Vercel'de çalışır

## Kullanım

1. `/admin/login` sayfasına gidin
2. Admin email ve şifre ile giriş yapın
3. İçerikleri düzenleyin
4. Kaydet butonuna basın
5. Değişiklikler GitHub'a commit edilir

## API Endpoints

- `GET /api/content/[key]` - İçerik okuma
- `POST /api/content/[key]` - İçerik güncelleme
- `POST /api/auth/login` - Giriş
- `POST /api/auth/logout` - Çıkış

## Güvenlik

- Middleware ile admin paneli koruması
- HTTP-only cookie kullanımı
- GitHub token server-side saklanır
- Environment variables ile yapılandırma
